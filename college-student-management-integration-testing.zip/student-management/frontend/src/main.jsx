import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import "./style.css";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

function App() {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState({ name: "", rollNo: "", branch: "" });
  const [message, setMessage] = useState("");

  async function loadStudents() {
    try {
      const response = await fetch(`${API}/students`);
      if (!response.ok) throw new Error("Could not load students");
      setStudents(await response.json());
    } catch {
      setMessage("Could not connect to the API. Make sure the backend and database are running.");
    }
  }

  useEffect(() => { loadStudents(); }, []);

  async function addStudent(event) {
    event.preventDefault();
    const response = await fetch(`${API}/students`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form)
    });
    if (response.ok) {
      setForm({ name: "", rollNo: "", branch: "" });
      setMessage("Student registered successfully.");
      loadStudents();
    } else {
      const result = await response.json();
      setMessage(result.error || "Could not register student.");
    }
  }

  async function deleteStudent(id) {
    const response = await fetch(`${API}/students/${id}`, { method: "DELETE" });
    if (response.ok) {
      setMessage("Student deleted.");
      loadStudents();
    }
  }

  return <main className="container">
    <h1>College Student Management</h1>
    <p className="subtitle">Register and manage student records</p>
    <form onSubmit={addStudent} className="student-form">
      {["name", "rollNo", "branch"].map(field =>
        <input key={field} required placeholder={field === "rollNo" ? "Roll Number" : field[0].toUpperCase() + field.slice(1)}
          value={form[field]} onChange={e => setForm({ ...form, [field]: e.target.value })} />
      )}
      <button type="submit">Register Student</button>
    </form>
    <p role="status">{message}</p>
    <h2>Students</h2>
    {students.length === 0 ? <p>No students found.</p> : <table>
      <thead><tr><th>Name</th><th>Roll Number</th><th>Branch</th><th>Action</th></tr></thead>
      <tbody>{students.map(s => <tr key={s.id}>
        <td>{s.name}</td><td>{s.rollNo}</td><td>{s.branch}</td>
        <td><button className="delete" onClick={() => deleteStudent(s.id)}>Delete</button></td>
      </tr>)}</tbody>
    </table>}
  </main>;
}

createRoot(document.getElementById("root")).render(<App />);
