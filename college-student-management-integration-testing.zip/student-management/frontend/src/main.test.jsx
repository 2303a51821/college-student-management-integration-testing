import { describe, expect, test } from "vitest";

describe("frontend test setup", () => {
  test("student form requires the core student fields", () => {
    const fields = ["name", "rollNo", "branch"];
    expect(fields).toContain("name");
    expect(fields).toContain("rollNo");
    expect(fields).toContain("branch");
  });
});
