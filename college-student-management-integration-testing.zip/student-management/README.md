# College Student Management System – Integration Testing

A React + Node.js/Express + PostgreSQL sample project with Jest/Supertest integration tests and GitHub Actions CI.

## Repository name
**college-student-management-integration-testing**

## Requirements
- Node.js 20+
- PostgreSQL 16+ (or Docker)
- npm

## Run locally

### 1. Start PostgreSQL
Create a database named `student_management` and set environment variables as needed.

Windows PowerShell:
```powershell
$env:DATABASE_URL="postgres://postgres:postgres@localhost:5432/student_management"
```

macOS/Linux:
```bash
export DATABASE_URL="postgres://postgres:postgres@localhost:5432/student_management"
```

### 2. Start backend
```bash
cd backend
npm install
npm start
```
The API listens on `http://localhost:5000`. The `students` table is created automatically.

### 3. Start frontend (in a second terminal)
```bash
cd frontend
npm install
npm run dev
```
Open the Vite URL shown in the terminal.

### 4. Run tests
Backend unit tests:
```bash
cd backend
npm test
```
Integration tests (requires PostgreSQL and `TEST_DATABASE_URL` or `DATABASE_URL`):
```bash
npm run test:integration
```
Frontend unit tests:
```bash
cd frontend
npm install
npm test
```

## API endpoints
- `GET /api/students`
- `GET /api/students/:id`
- `POST /api/students`
- `PUT /api/students/:id`
- `DELETE /api/students/:id`

Student fields: `name`, `rollNo`, `branch`. All are required and `rollNo` must be unique.

## CI pipeline
`.github/workflows/ci.yml` starts a PostgreSQL service, installs dependencies, runs backend unit tests, backend integration tests, frontend unit tests, and a frontend production build. Pull requests and pushes trigger the workflow.

## Failure scenario
To confirm failure detection, temporarily change the integration test URL from `/api/students` to `/api/student`. The integration test should fail with a 404. Restore the correct route and push the fix.

## Notes
The integration tests use a dedicated test database. Set `TEST_DATABASE_URL` locally to a separate database if you do not want tests to modify your development database.
