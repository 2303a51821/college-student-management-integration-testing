const express = require("express");
const cors = require("cors");
const { pool } = require("./db");

const app = express();
app.use(cors());
app.use(express.json());

app.get("/api/health", (_req, res) => res.json({ status: "ok" }));

app.get("/api/students", async (_req, res) => {
  try {
    const result = await pool.query('SELECT id, name, "rollNo", branch FROM students ORDER BY id');
    res.status(200).json(result.rows);
  } catch (error) {
    res.status(500).json({ error: "Failed to retrieve students" });
  }
});

app.get("/api/students/:id", async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, name, "rollNo", branch FROM students WHERE id = $1',
      [req.params.id]
    );
    if (!result.rowCount) return res.status(404).json({ error: "Student not found" });
    res.status(200).json(result.rows[0]);
  } catch (error) {
    res.status(400).json({ error: "Invalid student ID" });
  }
});

app.post("/api/students", async (req, res) => {
  const { name, rollNo, branch } = req.body || {};
  if (![name, rollNo, branch].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "name, rollNo, and branch are required" });
  }
  try {
    const result = await pool.query(
      'INSERT INTO students (name, "rollNo", branch) VALUES ($1, $2, $3) RETURNING id, name, "rollNo", branch',
      [name.trim(), rollNo.trim(), branch.trim()]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    if (error.code === "23505") return res.status(409).json({ error: "rollNo already exists" });
    res.status(500).json({ error: "Failed to create student" });
  }
});

app.put("/api/students/:id", async (req, res) => {
  const { name, rollNo, branch } = req.body || {};
  if (![name, rollNo, branch].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "name, rollNo, and branch are required" });
  }
  try {
    const result = await pool.query(
      'UPDATE students SET name = $1, "rollNo" = $2, branch = $3 WHERE id = $4 RETURNING id, name, "rollNo", branch',
      [name.trim(), rollNo.trim(), branch.trim(), req.params.id]
    );
    if (!result.rowCount) return res.status(404).json({ error: "Student not found" });
    res.status(200).json(result.rows[0]);
  } catch (error) {
    if (error.code === "23505") return res.status(409).json({ error: "rollNo already exists" });
    res.status(500).json({ error: "Failed to update student" });
  }
});

app.delete("/api/students/:id", async (req, res) => {
  try {
    const result = await pool.query("DELETE FROM students WHERE id = $1 RETURNING id", [req.params.id]);
    if (!result.rowCount) return res.status(404).json({ error: "Student not found" });
    res.status(204).send();
  } catch (error) {
    res.status(400).json({ error: "Invalid student ID" });
  }
});

module.exports = app;
