const request = require("supertest");
const { pool, initializeDatabase } = require("../db");
const app = require("../app");

describe("Student API + PostgreSQL integration tests", () => {
  let createdId;

  beforeAll(async () => {
    await initializeDatabase();
  });

  beforeEach(async () => {
    await pool.query("TRUNCATE TABLE students RESTART IDENTITY");
  });

  afterAll(async () => {
    await pool.end();
  });

  test("registers and retrieves a student from the database", async () => {
    const postResponse = await request(app).post("/api/students").send({
      name: "Rahul", rollNo: "CSE101", branch: "CSE"
    });
    expect(postResponse.statusCode).toBe(201);
    expect(postResponse.body.rollNo).toBe("CSE101");
    createdId = postResponse.body.id;

    const listResponse = await request(app).get("/api/students");
    expect(listResponse.statusCode).toBe(200);
    expect(listResponse.body.some(s => s.rollNo === "CSE101")).toBe(true);

    const detailResponse = await request(app).get(`/api/students/${createdId}`);
    expect(detailResponse.statusCode).toBe(200);
    expect(detailResponse.body.name).toBe("Rahul");
  });

  test("updates an existing student", async () => {
    const created = await request(app).post("/api/students").send({
      name: "Rahul", rollNo: "CSE102", branch: "CSE"
    });
    const response = await request(app).put(`/api/students/${created.body.id}`).send({
      name: "Rahul Kumar", rollNo: "CSE102", branch: "IT"
    });
    expect(response.statusCode).toBe(200);
    expect(response.body.name).toBe("Rahul Kumar");
    expect(response.body.branch).toBe("IT");
  });

  test("deletes a student and then returns 404 for retrieval", async () => {
    const created = await request(app).post("/api/students").send({
      name: "Anu", rollNo: "CSE103", branch: "CSE"
    });
    const id = created.body.id;
    const deleted = await request(app).delete(`/api/students/${id}`);
    expect(deleted.statusCode).toBe(204);
    const detail = await request(app).get(`/api/students/${id}`);
    expect(detail.statusCode).toBe(404);
  });

  test("rejects invalid student data", async () => {
    const response = await request(app).post("/api/students").send({
      name: "", rollNo: "CSE104", branch: "CSE"
    });
    expect(response.statusCode).toBe(400);
  });

  test("rejects duplicate roll numbers", async () => {
    const student = { name: "Asha", rollNo: "CSE105", branch: "CSE" };
    expect((await request(app).post("/api/students").send(student)).statusCode).toBe(201);
    expect((await request(app).post("/api/students").send(student)).statusCode).toBe(409);
  });
});
