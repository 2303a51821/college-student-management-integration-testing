const app = require("../app");
const request = require("supertest");

describe("Student API input validation (unit-level route tests)", () => {
  test("rejects student data with missing fields", async () => {
    const response = await request(app).post("/api/students").send({ name: "Rahul" });
    expect(response.statusCode).toBe(400);
    expect(response.body.error).toMatch(/required/i);
  });

  test("rejects the incorrect singular endpoint", async () => {
    const response = await request(app).post("/api/student").send({
      name: "Rahul", rollNo: "UNIT-101", branch: "CSE"
    });
    expect(response.statusCode).toBe(404);
  });
});
