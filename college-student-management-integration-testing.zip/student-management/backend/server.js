const app = require("./app");
const { initializeDatabase, pool } = require("./db");

const port = process.env.PORT || 5000;

initializeDatabase()
  .then(() => {
    app.listen(port, () => console.log(`Student API listening on port ${port}`));
  })
  .catch(async error => {
    console.error("Could not initialize database:", error.message);
    await pool.end();
    process.exit(1);
  });
