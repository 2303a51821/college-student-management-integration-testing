const { Pool } = require("pg");

const connectionString =
  process.env.TEST_DATABASE_URL ||
  process.env.DATABASE_URL ||
  "postgres://postgres:postgres@localhost:5432/student_management";

const pool = new Pool({ connectionString });

async function initializeDatabase() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS students (
      id SERIAL PRIMARY KEY,
      name VARCHAR(120) NOT NULL,
      "rollNo" VARCHAR(40) UNIQUE NOT NULL,
      branch VARCHAR(80) NOT NULL
    )
  `);
}

module.exports = { pool, initializeDatabase };
